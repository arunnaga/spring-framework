package com.ibm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Secured1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
