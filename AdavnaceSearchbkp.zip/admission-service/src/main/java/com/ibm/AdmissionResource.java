package com.ibm;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/admission")
public class AdmissionResource {

	
	public AdmissionResource() {
		// TODO Auto-generated constructor stub
	}
	@Autowired
	RestTemplate restTemplate;
	
	List<Patient> patients=Arrays.asList(new Patient("P1", "Arun", "INDIA"),
			new Patient("P2", "Arun", "INDIA"),
			new Patient("P3", "Arun", "INDIA"),
			new Patient("P4", "Arun", "INDIA")
			);
	
	@RequestMapping("/patients")
	public List<Patient> getPatients(){
	return patients;
		
	}
	@RequestMapping("/patients/{id}")
	public Patient getPatientById(@PathVariable("id") String id){
		Patient e=patients.stream().filter(Patient ->id.equals(Patient.getId()))
				.findAny()
				.orElse(null);
		return e;	
	}
	
	@RequestMapping("/physicians")
	public EmployeeList getPhysions(){
		EmployeeList emplist=restTemplate.getForObject("http://localhost:8882/hr/employees", EmployeeList.class);
		
		return emplist;
	
		
	}

}
