package com.ibm;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/bookrepo")
public class BookRepositoryService {

	@Autowired
	private BookRepository repository;
	public BookRepositoryService() {
		// TODO Auto-generated constructor stub
	}
	@RequestMapping("/books/{name}")
	public void saveBook(@PathVariable("name") String name){
		
		repository.save(new Book(name));
		
	}
	@RequestMapping("/books")
	public List<Book> getBooks(){
		List<Book> books=new ArrayList<>();
		repository.findAll().forEach(e->books.add(e));
		return books;	
	}
	
	@RequestMapping("/book/{id}")
	public String getBookById(@PathVariable("id") Long id){
		//repository.findById(id).ifPresent(id);	
		return repository.findById(id).toString();
		
	}

	@RequestMapping("/book/{name}")
	public String getBookByName(@PathVariable("name") String name){
		
		return repository.findByName(name).toString();
		
	}

}
