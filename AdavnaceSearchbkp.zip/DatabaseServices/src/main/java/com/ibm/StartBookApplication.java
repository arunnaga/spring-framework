package com.ibm;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartBookApplication implements CommandLineRunner{

	public StartBookApplication() {
		// TODO Auto-generated constructor stub
	}
	@Autowired
	private BookRepository repository;
	private static final Logger log=LoggerFactory.getLogger(StartBookApplication.class);

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		log.info("start book Application");
		repository.save(new Book("Java"));
		repository.save(new Book("JS"));
		repository.save(new Book("Java 8"));
		repository.save(new Book("Java 10"));
		System.out.println("FIndAll method");
		repository.findAll().forEach(x -> System.out.println(x));
		
		System.out.println("FIndAll method");
		repository.findAll().forEach(x -> System.out.println(x));
		
		
		System.out.println("FIndById method");
		repository.findById(1l).ifPresent(x -> System.out.println(x));
		
		System.out.println("FIndByName method");
		repository.findByName("Java").forEach(x -> System.out.println(x));	
		
		
	}
	public static void main(String[] args) {
		SpringApplication.run(StartBookApplication.class, args);
	}
	

}
