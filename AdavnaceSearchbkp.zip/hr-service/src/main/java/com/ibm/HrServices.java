package com.ibm;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hr")
public class HrServices {

	public HrServices() {
		// TODO Auto-generated constructor stub
	}
	
	List<Employee> empployees=Arrays.asList(new Employee("E1", "Arun", "Kumar", "Arun"),
			new Employee("E2", "Arun", "Kumar", "Arun"),
			new Employee("E3", "Arun", "Kumar", "Arun"),
			new Employee("E4", "Arun", "Kumar", "Arun")
			);
	
	@RequestMapping("/employees")
	public EmployeeList getEmployees(){
	EmployeeList empList=new EmployeeList();
	empList.setEmployee(empployees);
	return empList;
		
	}
	
	@RequestMapping("/employees/{id}")
	public Employee getEmployeeById(@PathVariable("id") String id){
		Employee e=empployees.stream().filter(Employee ->id.equals(Employee.getId()))
				.findAny()
				.orElse(null);
		return e;
	
		
	}
	

}
